Set Main_doc2.tex as the main file and compile with XeLaTeX. Keep figures/ alongside it. CAS support and bibliography are embedded in the source.
