Set Main_doc2.tex as the main file; compile with XeLaTeX. CAS support and bibliography are embedded. Keep the figures directory alongside the main file.
